package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView Boutput = (TextView)findViewById(R.id.textView5);
        Intent intent = getIntent();
        String Binput_EXTRA = intent.getStringExtra("Binput_EXTRA");
        Boutput.setText(Binput_EXTRA);
    }
    public void gotob(View view){
        EditText Ainput = (EditText)findViewById(R.id.editTextTextPersonName);
        String Ainput1 = Ainput.getText().toString();
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("A_EXTRA", Ainput1 );
        startActivity(intent);


    }


}