package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView Aoutput = (TextView)findViewById(R.id.textView5);
        Intent intent = getIntent();
        String A = intent.getStringExtra("A_EXTRA");
        Aoutput.setText(A);
    }
    public void gotoa(View view) {
        EditText Binput = (EditText)findViewById(R.id.editTextTextPersonName);
        String Binput1 = Binput.getText().toString();
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("Binput_EXTRA", Binput1);
        startActivity(intent);




    }

}